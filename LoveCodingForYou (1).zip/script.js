const cursor = document.querySelector(".cursor");
window.addEventListener("mousemove", function (e) {
  cursor.style.left = e.x - 50 + "px";
  cursor.style.top = e.y - 50 + "px";
});